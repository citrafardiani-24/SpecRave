package com.example.specrave.model

import com.google.firebase.database.PropertyName

data class User(
    @PropertyName("id") val id: String = "",
    @PropertyName("name") val name: String = "",
    @PropertyName("email") val email: String = "",
    @PropertyName("profile_photo") val profilePhoto: String = "",
    @PropertyName("created_at") val createdAt: String = ""
)