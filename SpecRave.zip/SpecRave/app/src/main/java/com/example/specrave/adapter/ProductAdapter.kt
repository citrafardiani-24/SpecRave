package com.example.specrave.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.specrave.R
import com.example.specrave.databinding.ItemProductBinding
import com.example.specrave.model.Phone
import java.text.NumberFormat
import java.util.Locale

class ProductAdapter(
    private val phones: MutableList<Phone>,
    private val onClick: (Phone) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    inner class ProductViewHolder(private val binding: ItemProductBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(phone: Phone) {
            binding.tvBrand.text = phone.brand
            binding.tvModel.text = phone.model
            binding.tvPrice.text = NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(phone.price)
            Glide.with(binding.root.context)
                .load(phone.imageUrl)
                .placeholder(R.drawable.placeholder_image)
                .error(R.drawable.placeholder_image)
                .into(binding.ivPhone)
            binding.root.setOnClickListener { onClick(phone) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val binding = ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(phones[position])
    }

    override fun getItemCount(): Int = phones.size

    fun updatePhones(newPhones: List<Phone>) {
        phones.clear()
        phones.addAll(newPhones)
        notifyDataSetChanged()
    }
}