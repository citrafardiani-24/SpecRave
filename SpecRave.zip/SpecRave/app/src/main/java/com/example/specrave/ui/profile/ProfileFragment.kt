package com.example.specrave.ui.profile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.specrave.R
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentProfileBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val auth = FirebaseAuth.getInstance()
    private val storage = FirebaseStorage.getInstance()
    private var selectedImageUri: Uri? = null
    private val TAG = "ProfileFragment"

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            selectedImageUri = result.data?.data
            selectedImageUri?.let { uri ->
                Log.d(TAG, "Selected image URI: $uri")
                // Verify URI accessibility
                try {
                    requireContext().contentResolver.openInputStream(uri)?.close()
                    Log.d(TAG, "Image URI is accessible")
                    Glide.with(this)
                        .load(uri)
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .placeholder(R.drawable.profil1)
                        .error(R.drawable.profil1)
                        .into(binding.profileLayout.ivProfilePhoto)
                } catch (e: Exception) {
                    Log.e(TAG, "Selected image URI is not accessible", e)
                    Snackbar.make(binding.root, "Gambar tidak dapat diakses: ${e.message}", Snackbar.LENGTH_LONG).show()
                    selectedImageUri = null
                }
            } ?: run {
                Log.e(TAG, "Selected image URI is null")
                Snackbar.make(binding.root, "Tidak ada gambar yang dipilih", Snackbar.LENGTH_SHORT).show()
            }
        } else {
            Log.e(TAG, "Image picker failed, resultCode=${result.resultCode}")
            Snackbar.make(binding.root, "Gagal memilih gambar", Snackbar.LENGTH_SHORT).show()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateUI()
    }

    private fun updateUI() {
        val user = auth.currentUser
        Log.d(TAG, "Updating UI, user=${user?.uid}")
        if (user == null) {
            showLoginForm()
        } else {
            showProfile()
            loadProfileData(user.uid)
        }
    }

    private fun showLoginForm() {
        binding.loginLayout.root.visibility = View.VISIBLE
        binding.profileLayout.root.visibility = View.GONE

        binding.loginLayout.btnLogin.setOnClickListener {
            val email = binding.loginLayout.etLoginEmail.text.toString().trim()
            val password = binding.loginLayout.etLoginPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Snackbar.make(binding.root, "Email dan password harus diisi", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            binding.progressBar.visibility = View.VISIBLE
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    binding.progressBar.visibility = View.GONE
                    if (task.isSuccessful) {
                        updateUI()
                        Snackbar.make(binding.root, "Login berhasil", Snackbar.LENGTH_SHORT).show()
                    } else {
                        val errorMessage = when (task.exception) {
                            is FirebaseAuthInvalidCredentialsException -> "Email atau password salah"
                            is FirebaseAuthInvalidUserException -> "Akun tidak ditemukan"
                            else -> "Login gagal: ${task.exception?.message}"
                        }
                        Snackbar.make(binding.root, errorMessage, Snackbar.LENGTH_LONG).show()
                    }
                }
        }

        binding.loginLayout.tvRegister.setOnClickListener {
            try {
                findNavController().navigate(R.id.action_profile_to_register)
            } catch (e: Exception) {
                Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun showProfile() {
        binding.loginLayout.root.visibility = View.GONE
        binding.profileLayout.root.visibility = View.VISIBLE

        binding.profileLayout.btnLogout.setOnClickListener {
            auth.signOut()
            updateUI()
            Snackbar.make(binding.root, "Logout berhasil", Snackbar.LENGTH_SHORT).show()
        }

        binding.profileLayout.btnEditProfile.setOnClickListener {
            val name = binding.profileLayout.etProfileName.text.toString().trim()
            val bio = binding.profileLayout.etProfileBio.text.toString().trim()

            if (name.isEmpty()) {
                Snackbar.make(binding.root, "Nama harus diisi", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            binding.progressBar.visibility = View.VISIBLE
            lifecycleScope.launch {
                try {
                    if (selectedImageUri != null) {
                        uploadProfilePhoto(auth.currentUser!!.uid) { photoUrl ->
                            saveProfileData(name, bio, photoUrl)
                        }
                    } else {
                        saveProfileData(name, bio, null)
                    }
                } catch (e: Exception) {
                    binding.progressBar.visibility = View.GONE
                    Log.e(TAG, "Failed to save profile", e)
                    Snackbar.make(binding.root, "Gagal menyimpan profil: ${e.message}", Snackbar.LENGTH_LONG).show()
                }
            }
        }

        binding.profileLayout.ivProfilePhoto.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK).apply { type = "image/*" }
            try {
                pickImageLauncher.launch(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to launch image picker", e)
                Snackbar.make(binding.root, "Gagal membuka pemilih gambar", Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadProfileData(uid: String) {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            when (val result = FirebaseService.getUserProfile(uid)) {
                is Result.Success -> {
                    binding.progressBar.visibility = View.GONE
                    binding.profileLayout.etProfileName.setText(result.data?.get("name")?.toString() ?: "")
                    binding.profileLayout.etProfileBio.setText(result.data?.get("bio")?.toString() ?: "")
                    val photoUrl = result.data?.get("photoUrl")?.toString()
                    Log.d(TAG, "Loading profile photo, photoUrl=$photoUrl")
                    if (!photoUrl.isNullOrBlank() && photoUrl != "" && photoUrl != "null") {
                        Glide.with(this@ProfileFragment)
                            .load(photoUrl)
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true)
                            .placeholder(R.drawable.profil1)
                            .error(R.drawable.profil1)
                            .into(binding.profileLayout.ivProfilePhoto)
                    } else {
                        Log.d(TAG, "photoUrl is invalid, loading profil1")
                        Glide.with(this@ProfileFragment)
                            .load(R.drawable.profil1)
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true)
                            .placeholder(R.drawable.profil1)
                            .error(R.drawable.profil1)
                            .into(binding.profileLayout.ivProfilePhoto)
                    }
                }
                is Result.Failure -> {
                    binding.progressBar.visibility = View.GONE
                    Log.e(TAG, "Failed to load profile data", result.exception)
                    Snackbar.make(binding.root, R.string.error_load_profile, Snackbar.LENGTH_LONG).show()
                    Glide.with(this@ProfileFragment)
                        .load(R.drawable.profil1)
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .placeholder(R.drawable.profil1)
                        .error(R.drawable.profil1)
                        .into(binding.profileLayout.ivProfilePhoto)
                }
            }
        }
    }

    private fun uploadProfilePhoto(uid: String, callback: (String?) -> Unit) {
        selectedImageUri?.let { uri ->
            Log.d(TAG, "Uploading profile photo for uid=$uid, uri=$uri")
            val storageRef = storage.reference.child("images/users/$uid.jpg")
            // Verify URI accessibility
            try {
                requireContext().contentResolver.openInputStream(uri)?.close()
                Log.d(TAG, "Image URI is valid and accessible")
            } catch (e: Exception) {
                Log.e(TAG, "Invalid or inaccessible image URI", e)
                binding.progressBar.visibility = View.GONE
                Snackbar.make(binding.root, "Gambar tidak valid atau tidak dapat diakses: ${e.message}", Snackbar.LENGTH_LONG).show()
                callback(null)
                return
            }
            val uploadTask = storageRef.putFile(uri)
            uploadTask
                .addOnProgressListener { taskSnapshot ->
                    val progress = (100.0 * taskSnapshot.bytesTransferred / taskSnapshot.totalByteCount).toInt()
                    Log.d(TAG, "Upload progress: $progress%")
                }
                .addOnSuccessListener {
                    storageRef.downloadUrl.addOnSuccessListener { downloadUri ->
                        Log.d(TAG, "Photo uploaded successfully, downloadUrl=$downloadUri")
                        callback(downloadUri.toString())
                    }.addOnFailureListener { e ->
                        Log.e(TAG, "Failed to get download URL", e)
                        binding.progressBar.visibility = View.GONE
                        Snackbar.make(binding.root, "Gagal mendapatkan URL foto: ${e.message}", Snackbar.LENGTH_LONG).show()
                        callback(null)
                    }
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Failed to upload photo", e)
                    binding.progressBar.visibility = View.GONE
                    Snackbar.make(binding.root, "Gagal mengunggah foto: ${e.message}", Snackbar.LENGTH_LONG).show()
                    callback(null)
                }
        } ?: run {
            Log.d(TAG, "No image selected for upload")
            binding.progressBar.visibility = View.GONE
            Snackbar.make(binding.root, "Tidak ada gambar yang dipilih", Snackbar.LENGTH_SHORT).show()
            callback(null)
        }
    }

    private fun saveProfileData(name: String, bio: String, photoUrl: String?) {
        val user = auth.currentUser ?: return
        val profileData = mutableMapOf<String, Any>(
            "name" to name,
            "bio" to bio,
            "email" to user.email!!,
            "joinDate" to (SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
        )
        // Only include photoUrl if valid; remove it if null to avoid empty strings
        if (!photoUrl.isNullOrBlank() && photoUrl != "null") {
            profileData["photoUrl"] = photoUrl
        } else {
            profileData["photoUrl"] = "" // Reset to empty string to clear invalid URLs
        }

        lifecycleScope.launch {
            when (val result = FirebaseService.updateUserProfile(user.uid, profileData)) {
                is Result.Success -> {
                    binding.progressBar.visibility = View.GONE
                    Snackbar.make(binding.root, "Profil diperbarui", Snackbar.LENGTH_SHORT).show()
                    selectedImageUri = null
                    // Reload profile to update UI
                    loadProfileData(user.uid)
                }
                is Result.Failure -> {
                    binding.progressBar.visibility = View.GONE
                    Log.e(TAG, "Failed to save profile data", result.exception)
                    Snackbar.make(binding.root, "Gagal menyimpan profil: ${result.exception.message}", Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}