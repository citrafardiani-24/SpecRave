package com.example.specrave.ui.profile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.specrave.R
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentProfileBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val auth = FirebaseAuth.getInstance()
    private val storage = FirebaseStorage.getInstance()
    private var selectedImageUri: Uri? = null

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            selectedImageUri = result.data?.data
            selectedImageUri?.let {
                Glide.with(this).load(it).into(binding.profileLayout.ivProfilePhoto)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        updateUI()
    }

    private fun updateUI() {
        val user = auth.currentUser
        if (user == null) {
            showLoginForm()
        } else {
            showProfile()
            loadProfileData(user.uid)
        }
    }

    private fun showLoginForm() {
        binding.loginLayout.root.visibility = View.VISIBLE
        binding.profileLayout.root.visibility = View.GONE

        binding.loginLayout.btnLogin.setOnClickListener {
            val email = binding.loginLayout.etLoginEmail.text.toString().trim()
            val password = binding.loginLayout.etLoginPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Snackbar.make(binding.root, "Email dan password harus diisi", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            binding.progressBar.visibility = View.VISIBLE
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    binding.progressBar.visibility = View.GONE
                    if (task.isSuccessful) {
                        updateUI()
                        Snackbar.make(binding.root, "Login berhasil", Snackbar.LENGTH_SHORT).show()
                    } else {
                        val errorMessage = when (task.exception) {
                            is FirebaseAuthInvalidCredentialsException -> "Email atau password salah"
                            is FirebaseAuthInvalidUserException -> "Akun tidak ditemukan"
                            else -> "Login gagal: ${task.exception?.message}"
                        }
                        Snackbar.make(binding.root, errorMessage, Snackbar.LENGTH_LONG).show()
                    }
                }
        }

        binding.loginLayout.tvRegister.setOnClickListener {
            try {
                findNavController().navigate(R.id.action_profile_to_register)
            } catch (e: Exception) {
                Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun showProfile() {
        binding.loginLayout.root.visibility = View.GONE
        binding.profileLayout.root.visibility = View.VISIBLE

        binding.profileLayout.btnLogout.setOnClickListener {
            auth.signOut()
            updateUI()
            Snackbar.make(binding.root, "Logout berhasil", Snackbar.LENGTH_SHORT).show()
        }

        binding.profileLayout.btnEditProfile.setOnClickListener {
            val name = binding.profileLayout.etProfileName.text.toString().trim()
            val bio = binding.profileLayout.etProfileBio.text.toString().trim()

            if (name.isEmpty()) {
                Snackbar.make(binding.root, "Nama harus diisi", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            binding.progressBar.visibility = View.VISIBLE
            lifecycleScope.launch {
                try {
                    if (selectedImageUri != null) {
                        uploadProfilePhoto(auth.currentUser!!.uid) { photoUrl ->
                            saveProfileData(name, bio, photoUrl)
                        }
                    } else {
                        saveProfileData(name, bio, null)
                    }
                } catch (e: Exception) {
                    binding.progressBar.visibility = View.GONE
                    Snackbar.make(binding.root, "Gagal menyimpan profil: ${e.message}", Snackbar.LENGTH_LONG).show()
                }
            }
        }

        binding.profileLayout.ivProfilePhoto.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK).apply { type = "image/*" }
            pickImageLauncher.launch(intent)
        }
    }

    private fun loadProfileData(uid: String) {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            when (val result = FirebaseService.getUserProfile(uid)) {
                is Result.Success -> {
                    binding.progressBar.visibility = View.GONE
                    binding.profileLayout.etProfileName.setText(result.data?.get("name")?.toString() ?: "")
                    binding.profileLayout.etProfileBio.setText(result.data?.get("bio")?.toString() ?: "")
                    val photoUrl = result.data?.get("photoUrl")?.toString()
                    Glide.with(this@ProfileFragment)
                        .load(photoUrl ?: R.drawable.profil1)
                        .into(binding.profileLayout.ivProfilePhoto)
                }
                is Result.Failure -> {
                    binding.progressBar.visibility = View.GONE
                    Snackbar.make(binding.root, R.string.error_load_profile, Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun uploadProfilePhoto(uid: String, callback: (String?) -> Unit) {
        selectedImageUri?.let { uri ->
            val storageRef = storage.reference.child("images/users/$uid.jpg")
            storageRef.putFile(uri)
                .addOnSuccessListener {
                    storageRef.downloadUrl.addOnSuccessListener { downloadUri ->
                        callback(downloadUri.toString())
                    }.addOnFailureListener {
                        binding.progressBar.visibility = View.GONE
                        Snackbar.make(binding.root, "Gagal mengunggah foto", Snackbar.LENGTH_LONG).show()
                        callback(null)
                    }
                }
                .addOnFailureListener {
                    binding.progressBar.visibility = View.GONE
                    Snackbar.make(binding.root, "Gagal mengunggah foto", Snackbar.LENGTH_LONG).show()
                    callback(null)
                }
        } ?: callback(null)
    }

    private fun saveProfileData(name: String, bio: String, photoUrl: String?) {
        val user = auth.currentUser ?: return
        val profileData = mutableMapOf<String, Any>(
            "name" to name,
            "bio" to bio,
            "email" to user.email!!,
            "joinDate" to (SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
        )
        photoUrl?.let { profileData["photoUrl"] = it }

        lifecycleScope.launch {
            when (val result = FirebaseService.updateUserProfile(user.uid, profileData)) {
                is Result.Success -> {
                    binding.progressBar.visibility = View.GONE
                    Snackbar.make(binding.root, "Profil diperbarui", Snackbar.LENGTH_SHORT).show()
                    selectedImageUri = null
                }
                is Result.Failure -> {
                    binding.progressBar.visibility = View.GONE
                    Snackbar.make(binding.root, "Gagal menyimpan profil", Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}