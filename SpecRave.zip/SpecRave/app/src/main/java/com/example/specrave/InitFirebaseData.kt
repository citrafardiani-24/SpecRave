
package com.example.specrave

import androidx.core.net.toUri
import com.example.specrave.model.Phone
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.File

fun initializeFirebaseData() {
    val database = FirebaseDatabase.getInstance().reference
    val storage = FirebaseStorage.getInstance().reference

    val phones = arrayListOf(
        Phone(
            id = "phone_1",
            brand = "Samsung",
            model = "Galaxy S23 Ultra",
            price = 18000000L, // Konversi ke Long
            screenSize = 6.8,
            storage = 256, // Int sesuai dengan Phone.kt
            ram = 12, // Int sesuai dengan Phone.kt
            battery = 5000,
            camera = "200", // String sesuai dengan Phone.kt
            chipset = "Snapdragon 8 Gen 2",
            is5g = true,
            categories = listOf("kamera"), // Mengganti category dengan categories
            imageUrl = "",
            searchCount = 10L // Konversi ke Long
        ),
        Phone(
            id = "phone_2",
            brand = "Apple",
            model = "iPhone 14 Pro",
            price = 20000000L,
            screenSize = 6.1,
            storage = 128,
            ram = 6,
            battery = 3200,
            camera = "48",
            chipset = "A16 Bionic",
            is5g = true,
            categories = listOf("kamera"),
            imageUrl = "",
            searchCount = 8L
        ),
        Phone(
            id = "phone_3",
            brand = "Xiaomi",
            model = "13 Pro",
            price = 12000000L,
            screenSize = 6.73,
            storage = 256,
            ram = 12,
            battery = 4820,
            camera = "50",
            chipset = "Snapdragon 8 Gen 2",
            is5g = true,
            categories = listOf("gaming"),
            imageUrl = "",
            searchCount = 6L
        ),
        Phone(
            id = "phone_4",
            brand = "OnePlus",
            model = "11",
            price = 14000000L,
            screenSize = 6.7,
            storage = 256,
            ram = 16,
            battery = 5000,
            camera = "50",
            chipset = "Snapdragon 8 Gen 2",
            is5g = true,
            categories = listOf("baterai"),
            imageUrl = "",
            searchCount = 4L
        ),
        Phone(
            id = "phone_5",
            brand = "Google",
            model = "Pixel 7 Pro",
            price = 13000000L,
            screenSize = 6.7,
            storage = 128,
            ram = 12,
            battery = 5000,
            camera = "50",
            chipset = "Tensor G2",
            is5g = true,
            categories = listOf("kamera"),
            imageUrl = "",
            searchCount = 2L
        )
    )

    CoroutineScope(Dispatchers.IO).launch {
        phones.forEach { phone ->
            // Upload image to Firebase Storage (ganti dengan path file gambar lokal)
            val imageFile = File("app/src/main/assets/images/${phone.brand}_${phone.model}.jpg")
            val imageRef = storage.child("images/phones/${phone.id}.jpg")
            try {
                imageRef.putFile(imageFile.toUri()).await()
                val imageUrl = imageRef.downloadUrl.await().toString()
                // Save phone to Realtime Database
                database.child("phones").child(phone.id).setValue(phone.copy(imageUrl = imageUrl)).await()
            } catch (e: Exception) {
                // Log error jika file tidak ditemukan atau upload gagal
                println("Error uploading ${phone.brand} ${phone.model}: ${e.message}")
            }
        }
    }
}