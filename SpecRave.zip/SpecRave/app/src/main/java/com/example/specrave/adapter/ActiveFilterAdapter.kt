package com.example.specrave.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.specrave.databinding.ItemFilterBinding
import com.example.specrave.ui.jelajahi.Filter

class ActiveFilterAdapter(
    private val filters: MutableList<Filter>,
    private val onRemoveClick: (Filter) -> Unit
) : RecyclerView.Adapter<ActiveFilterAdapter.FilterViewHolder>() {

    class FilterViewHolder(private val binding: ItemFilterBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(filter: Filter, onRemoveClick: (Filter) -> Unit) {
            binding.tvFilterValue.text = filter.value
            binding.ivRemove.setOnClickListener { onRemoveClick(filter) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilterViewHolder {
        val binding = ItemFilterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FilterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FilterViewHolder, position: Int) {
        holder.bind(filters[position], onRemoveClick)
    }

    override fun getItemCount(): Int = filters.size

    fun updateFilters(newFilters: List<Filter>) {
        filters.clear()
        filters.addAll(newFilters)
        notifyDataSetChanged()
    }
}