package com.example.specrave.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.specrave.R

data class Filter(val name: String, val value: String)

class ActiveFilterAdapter(
    private val filters: MutableList<Filter>,
    private val onRemoveClick: (Filter) -> Unit
) : RecyclerView.Adapter<ActiveFilterAdapter.FilterViewHolder>() {

    class FilterViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvFilterValue: TextView = itemView.findViewById(R.id.tvFilterValue)
        val ivRemove: ImageView = itemView.findViewById(R.id.ivRemove)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilterViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_active_filter_chip, parent, false)
        return FilterViewHolder(view)
    }

    override fun onBindViewHolder(holder: FilterViewHolder, position: Int) {
        val filter = filters[position]
        holder.tvFilterValue.text = filter.value
        holder.ivRemove.setOnClickListener { onRemoveClick(filter) }
    }

    override fun getItemCount(): Int = filters.size

    fun updateFilters(newFilters: List<Filter>) {
        filters.clear()
        filters.addAll(newFilters)
        notifyDataSetChanged()
    }
}