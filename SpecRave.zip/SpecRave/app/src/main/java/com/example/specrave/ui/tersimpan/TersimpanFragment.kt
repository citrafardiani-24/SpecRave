package com.example.specrave.ui.tersimpan

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.specrave.R
import com.example.specrave.adapter.ProductAdapter
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentTersimpanBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class TersimpanFragment : Fragment() {

    private var _binding: FragmentTersimpanBinding? = null
    private val binding get() = _binding!!
    private lateinit var productAdapter: ProductAdapter
    private val auth = FirebaseAuth.getInstance()
    private val TAG = "TersimpanFragment"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTersimpanBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        productAdapter = ProductAdapter(mutableListOf()) { phone ->
            try {
                val action = TersimpanFragmentDirections.actionTersimpanToDetailProduk(phone.id)
                findNavController().navigate(action)
            } catch (e: Exception) {
                Log.e(TAG, "Navigation error to DetailProduk", e)
                Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
            }
        }
        binding.rvSavedPhones.layoutManager = LinearLayoutManager(context)
        binding.rvSavedPhones.adapter = productAdapter

        binding.profileImage.setOnClickListener {
            try {
                findNavController().navigate(R.id.navigation_Profile)
            } catch (e: Exception) {
                Log.e(TAG, "Navigation error to Profile", e)
                Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
            }
        }

        loadSavedPhones()
    }

    private fun loadSavedPhones() {
        val user = auth.currentUser
        if (user == null) {
            binding.progressBar.visibility = View.GONE
            binding.contentLayout.visibility = View.GONE
            binding.errorLayout.visibility = View.VISIBLE
            binding.tvErrorMessage.text = "Silakan login untuk melihat ponsel tersimpan"
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.contentLayout.visibility = View.GONE
        binding.errorLayout.visibility = View.GONE

        lifecycleScope.launch {
            when (val result = FirebaseService.getSavedPhones(user.uid)) {
                is Result.Success -> {
                    binding.progressBar.visibility = View.GONE
                    if (result.data.isEmpty()) {
                        binding.errorLayout.visibility = View.VISIBLE
                        binding.tvErrorMessage.text = getString(R.string.error_empty_products)
                        binding.contentLayout.visibility = View.GONE
                    } else {
                        productAdapter.updatePhones(result.data)
                        binding.contentLayout.visibility = View.VISIBLE
                        binding.errorLayout.visibility = View.GONE
                        binding.tvSavedCount.text = "${result.data.size} Produk"
                    }
                }
                is Result.Failure -> {
                    binding.progressBar.visibility = View.GONE
                    binding.errorLayout.visibility = View.VISIBLE
                    binding.contentLayout.visibility = View.GONE
                    binding.tvErrorMessage.text = getString(R.string.error_load_products)
                    Snackbar.make(binding.root, R.string.error_load_products, Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) { loadSavedPhones() }
                        .show()
                    Log.e(TAG, "Failed to load saved phones", result.exception)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}