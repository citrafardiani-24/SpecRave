package com.example.specrave.ui.jelajahi

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.specrave.R
import com.example.specrave.adapter.ActiveFilterAdapter
import com.example.specrave.adapter.ProductAdapter
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentHasilsearchBinding
import com.example.specrave.model.Phone
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class HasilSearchFragment : Fragment() {

    private var _binding: FragmentHasilsearchBinding? = null
    private val binding get() = _binding!!
    private lateinit var productAdapter: ProductAdapter
    private lateinit var activeFilterAdapter: ActiveFilterAdapter
    private val activeFilters = mutableListOf<Filter>()
    private val TAG = "HasilSearchFragment"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHasilsearchBinding.inflate(inflater, container, false)
        Log.d(TAG, "onCreateView: HasilSearchFragment view created")
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d(TAG, "onViewCreated: Setting up fragment")

        // Setup RecyclerViews
        productAdapter = ProductAdapter(mutableListOf()) { phone ->
            try {
                val action = HasilSearchFragmentDirections.actionHasilSearchToDetailProduk(phone.id)
                findNavController().navigate(action)
                Log.d(TAG, "Navigating to DetailProduk for phone ID: ${phone.id}")
            } catch (e: Exception) {
                Log.e(TAG, "Navigation error to DetailProduk", e)
                Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
            }
        }
        binding.rvProducts.layoutManager = LinearLayoutManager(context)
        binding.rvProducts.adapter = productAdapter

        activeFilterAdapter = ActiveFilterAdapter(activeFilters) { filter ->
            activeFilters.remove(filter)
            updateActiveFilters()
            applyFilters()
            Log.d(TAG, "Filter removed: $filter, new filters: $activeFilters")
        }
        binding.rvActiveFilters.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        binding.rvActiveFilters.adapter = activeFilterAdapter

        // Setup Search
        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {
                val query = binding.etSearch.text.toString().trim()
                if (query.isNotEmpty()) {
                    searchPhones(query)
                    Log.d(TAG, "Search initiated with query: $query")
                }
                true
            } else false
        }
        binding.ivClearSearch.setOnClickListener {
            binding.etSearch.text.clear()
            binding.ivClearSearch.visibility = View.GONE
            clearSearchResults()
            Log.d(TAG, "Search cleared")
        }
        binding.etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.ivClearSearch.visibility = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        // Setup Filter
        binding.btnFilter.setOnClickListener {
            try {
                val filterDialog = FilterDialogFragment.newInstance { filters ->
                    activeFilters.clear()
                    activeFilters.addAll(filters)
                    updateActiveFilters()
                    applyFilters()
                    Log.d(TAG, "Filters applied from dialog: $filters")
                }
                filterDialog.show(parentFragmentManager, "FilterDialog")
                Log.d(TAG, "Filter dialog shown")
            } catch (e: Exception) {
                Log.e(TAG, "Error showing FilterDialog", e)
                Snackbar.make(binding.root, R.string.error_open_filter, Snackbar.LENGTH_SHORT).show()
            }
        }

        // Handle arguments
        arguments?.getParcelableArrayList<Filter>("filters")?.let { filters ->
            activeFilters.clear()
            activeFilters.addAll(filters)
            updateActiveFilters()
            applyFilters()
            Log.d(TAG, "Received filters from arguments: $filters")
        }
        arguments?.getString("category")?.let { category ->
            fetchCategoryPhones(category)
            Log.d(TAG, "Received category: $category")
        }
        // Jika tidak ada argumen, tampilkan pesan kosong
        if (arguments?.getParcelableArrayList<Filter>("filters") == null && arguments?.getString("category") == null) {
            binding.rvProducts.visibility = View.GONE
            binding.tvNoResults.visibility = View.VISIBLE
            binding.tvNoResults.text = getString(R.string.error_empty_products)
            Log.d(TAG, "No filters or category received, showing empty state")
        }
    }

    private fun searchPhones(keyword: String) {
        binding.rvProducts.visibility = View.GONE
        binding.tvNoResults.visibility = View.GONE
        binding.tvResultsTitle.visibility = View.VISIBLE
        lifecycleScope.launch {
            Log.d(TAG, "Searching phones with keyword: $keyword")
            when (val result = FirebaseService.searchPhones(keyword)) {
                is Result.Success -> {
                    updateResults(result.data)
                    Log.d(TAG, "Search successful, phones found: ${result.data.size}")
                }
                is Result.Failure -> {
                    binding.rvProducts.visibility = View.GONE
                    binding.tvNoResults.visibility = View.VISIBLE
                    binding.tvNoResults.text = getString(R.string.error_load_products)
                    Snackbar.make(binding.root, R.string.error_load_products, Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) { searchPhones(keyword) }
                        .show()
                    Log.e(TAG, "Failed to search phones with keyword: $keyword", result.exception)
                }
            }
        }
    }

    private fun fetchCategoryPhones(category: String) {
        binding.rvProducts.visibility = View.GONE
        binding.tvNoResults.visibility = View.GONE
        binding.tvResultsTitle.visibility = View.VISIBLE
        lifecycleScope.launch {
            Log.d(TAG, "Fetching phones for category: $category")
            when (val result = FirebaseService.getCategoryPhones(category)) {
                is Result.Success -> {
                    updateResults(result.data)
                    Log.d(TAG, "Category fetch successful, phones found: ${result.data.size}")
                }
                is Result.Failure -> {
                    binding.rvProducts.visibility = View.GONE
                    binding.tvNoResults.visibility = View.VISIBLE
                    binding.tvNoResults.text = getString(R.string.error_load_products)
                    Snackbar.make(binding.root, R.string.error_load_products, Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) { fetchCategoryPhones(category) }
                        .show()
                    Log.e(TAG, "Failed to fetch phones for category: $category", result.exception)
                }
            }
        }
    }

    private fun applyFilters() {
        binding.rvProducts.visibility = View.GONE
        binding.tvNoResults.visibility = View.GONE
        binding.tvResultsTitle.visibility = View.VISIBLE
        Log.d(TAG, "Active filters before applying: $activeFilters")
        val priceRange = activeFilters.find { it.name == "price_range" }?.value
        val brands = activeFilters.filter { it.name == "brand" }.map { it.value }
        val screenSizes = activeFilters.filter { it.name == "screen_size" }.map { it.value }
        val storages = activeFilters.filter { it.name == "storage" }.map { it.value }
        val is5g = activeFilters.find { it.name == "is_5g" }?.value?.let { it == "5G" }
        Log.d(TAG, "Applying filters: priceRange=$priceRange, brands=$brands, screenSizes=$screenSizes, storages=$storages, is5g=$is5g")

        lifecycleScope.launch {
            when (val result = FirebaseService.filterPhones(priceRange, brands, screenSizes, storages, is5g)) {
                is Result.Success -> {
                    updateResults(result.data)
                    Log.d(TAG, "Filter successful, phones found: ${result.data.size}")
                }
                is Result.Failure -> {
                    binding.rvProducts.visibility = View.GONE
                    binding.tvNoResults.visibility = View.VISIBLE
                    binding.tvNoResults.text = getString(R.string.error_load_products)
                    Snackbar.make(binding.root, R.string.error_load_products, Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) { applyFilters() }
                        .show()
                    Log.e(TAG, "Failed to apply filters", result.exception)
                }
            }
        }
    }

    private fun updateResults(phones: List<Phone>) {
        if (phones.isEmpty()) {
            binding.tvResultsTitle.visibility = View.VISIBLE
            binding.rvProducts.visibility = View.GONE
            binding.tvNoResults.visibility = View.VISIBLE
            binding.tvNoResults.text = getString(R.string.error_empty_products)
            Snackbar.make(binding.root, R.string.error_empty_products, Snackbar.LENGTH_LONG)
                .setAction(R.string.retry) { applyFilters() }
                .show()
            Log.d(TAG, "No phones found after filtering")
        } else {
            productAdapter.updatePhones(phones)
            binding.tvResultsTitle.visibility = View.VISIBLE
            binding.rvProducts.visibility = View.VISIBLE
            binding.tvNoResults.visibility = View.GONE
            Log.d(TAG, "Phones updated in adapter: ${phones.size}")
        }
    }

    private fun updateActiveFilters() {
        activeFilterAdapter.updateFilters(activeFilters)
        binding.rvActiveFilters.visibility = if (activeFilters.isEmpty()) View.GONE else View.VISIBLE
        binding.tvFilterCount.text = activeFilters.size.toString()
        binding.tvFilterCount.visibility = if (activeFilters.isEmpty()) View.GONE else View.VISIBLE
        Log.d(TAG, "Active filters updated: $activeFilters")
    }

    private fun clearSearchResults() {
        binding.tvResultsTitle.visibility = View.GONE
        binding.rvProducts.visibility = View.GONE
        binding.tvNoResults.visibility = View.GONE
        activeFilters.clear()
        updateActiveFilters()
        Log.d(TAG, "Search results cleared")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d(TAG, "onDestroyView: Cleaning up")
        _binding = null
    }
}