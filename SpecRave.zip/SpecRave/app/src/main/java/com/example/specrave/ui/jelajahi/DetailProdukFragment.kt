package com.example.specrave.ui.jelajahi

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.specrave.R
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentDetailProdukBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class DetailProdukFragment : Fragment() {

    private var _binding: FragmentDetailProdukBinding? = null
    private val binding get() = _binding!!
    private val auth = FirebaseAuth.getInstance()
    private val TAG = "DetailProdukFragment"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailProdukBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val phoneId = arguments?.getString("phoneId") ?: return
        loadPhoneDetails(phoneId)

        binding.btnSave.setOnClickListener {
            val user = auth.currentUser
            if (user == null) {
                Snackbar.make(binding.root, "Silakan login untuk menyimpan produk", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                when (val isSavedResult = FirebaseService.isPhoneSaved(user.uid, phoneId)) {
                    is Result.Success -> {
                        if (isSavedResult.data) {
                            // Unsave
                            when (val result = FirebaseService.unsavePhone(user.uid, phoneId)) {
                                is Result.Success -> {
                                    binding.btnSave.setImageResource(R.drawable.ic_save)
                                    Snackbar.make(binding.root, "Produk dihapus dari tersimpan", Snackbar.LENGTH_SHORT).show()
                                }
                                is Result.Failure -> {
                                    Snackbar.make(binding.root, "Gagal menghapus produk", Snackbar.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            // Save
                            when (val result = FirebaseService.savePhone(user.uid, phoneId)) {
                                is Result.Success -> {
                                    binding.btnSave.setImageResource(R.drawable.ic_saved)
                                    Snackbar.make(binding.root, "Produk disimpan", Snackbar.LENGTH_SHORT).show()
                                }
                                is Result.Failure -> {
                                    Snackbar.make(binding.root, "Gagal menyimpan produk", Snackbar.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                    is Result.Failure -> {
                        Snackbar.make(binding.root, "Gagal memeriksa status produk", Snackbar.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun loadPhoneDetails(phoneId: String) {
        binding.progressBar.visibility = View.VISIBLE
        binding.contentLayout.visibility = View.GONE
        binding.errorLayout.visibility = View.GONE

        lifecycleScope.launch {
            when (val result = FirebaseService.getPhoneById(phoneId)) {
                is Result.Success -> {
                    binding.progressBar.visibility = View.GONE
                    binding.contentLayout.visibility = View.VISIBLE
                    val phone = result.data
                    Glide.with(this@DetailProdukFragment)
                        .load(phone.imageUrl)
                        .placeholder(R.drawable.placeholder_image)
                        .error(R.drawable.placeholder_image)
                        .into(binding.imgProduk)
                    binding.tvNamaProduk.text = "${phone.brand} ${phone.model}"
                    val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
                    binding.tvHargaProduk.text = formatter.format(phone.price)
                    binding.tvSpesifikasi.text = """
                        RAM: ${phone.ram}GB
                        Storage: ${phone.storage}GB
                        Camera: ${phone.camera}
                        OS: ${phone.os}
                        Release Year: ${phone.releaseYear}
                        Screen Size: ${phone.screenSize}"
                        Battery: ${phone.battery}mAh
                        5G: ${if (phone.is5g) "Yes" else "No"}
                        Categories: ${phone.categories.joinToString(", ")}
                    """.trimIndent()

                    // Check if phone is saved
                    auth.currentUser?.let { user ->
                        when (val isSavedResult = FirebaseService.isPhoneSaved(user.uid, phoneId)) {
                            is Result.Success -> {
                                binding.btnSave.setImageResource(
                                    if (isSavedResult.data) R.drawable.ic_save else R.drawable.ic_saved
                                )
                            }
                            is Result.Failure -> {
                                // Silent error
                            }
                        }
                    }
                }
                is Result.Failure -> {
                    binding.progressBar.visibility = View.GONE
                    binding.errorLayout.visibility = View.VISIBLE
                    binding.tvErrorMessage.text = getString(R.string.error_load_products)
                    Snackbar.make(binding.root, R.string.error_load_products, Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) { loadPhoneDetails(phoneId) }
                        .show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}