package com.example.specrave.ui.banding

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.specrave.R
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentBandingBinding
import com.example.specrave.model.Phone
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class BandingFragment : Fragment() {

    private var _binding: FragmentBandingBinding? = null
    private val binding get() = _binding!!
    private val selectedPhones = mutableListOf<Phone>()
    private val selectedPhoneIds = mutableListOf<String>()
    private val TAG = "BandingFragment"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBandingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.getStringArrayList("selectedPhoneIds")?.let { ids ->
            Log.d(TAG, "Menerima ID ponsel dari arguments: $ids")
            if (ids.isNotEmpty() && ids != selectedPhoneIds) {
                selectedPhoneIds.clear()
                selectedPhoneIds.addAll(ids)
                loadSelectedPhones()
            }
        } ?: updateUI() // Panggil updateUI jika tidak ada argumen untuk menampilkan state awal

        binding.cardAddPhone.setOnClickListener {
            if (selectedPhoneIds.size >= 4) {
                Snackbar.make(binding.root, "Maksimal 4 ponsel untuk perbandingan", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            try {
                val bundle = Bundle().apply { putStringArrayList("selectedPhoneIds", ArrayList(selectedPhoneIds)) }
                findNavController().navigate(R.id.action_banding_to_selectPhone, bundle)
            } catch (e: Exception) {
                Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
            }
        }

        binding.chipGroupCategories.setOnCheckedChangeListener { _, checkedId ->
            updateComparisonContent()
        }
    }

    private fun loadSelectedPhones() {
        binding.progressBar.visibility = View.VISIBLE
        binding.contentLayout.visibility = View.GONE
        binding.llEmptyState.visibility = View.GONE

        Log.d(TAG, "Mulai menjalankan loadSelectedPhones()...")

        lifecycleScope.launch {
            selectedPhones.clear()
            for (phoneId in selectedPhoneIds) {
                Log.d(TAG, "Mencoba mengambil data untuk ID: $phoneId")
                when (val result = FirebaseService.getPhoneById(phoneId)) {
                    is Result.Success -> {
                        result.data?.let { phone: Phone ->
                            selectedPhones.add(phone)
                            Log.d(TAG, "Sukses mengambil dan menambahkan: ${phone.brand} ${phone.model}")
                        }
                    }
                    is Result.Failure -> {
                        Log.e(TAG, "Gagal mengambil data untuk ID: $phoneId", result.exception)
                        Snackbar.make(binding.root, "Gagal memuat ponsel $phoneId", Snackbar.LENGTH_SHORT).show()
                    }
                }
            }
            binding.progressBar.visibility = View.GONE

            Log.d(TAG, "Proses loop selesai. Jumlah ponsel yang berhasil dimuat: ${selectedPhones.size}")

            updateUI()
        }
    }

    private fun updateUI() {
        Log.d(TAG, "Memulai updateUI(). Jumlah ponsel saat ini: ${selectedPhones.size}")

        binding.contentLayout.visibility = View.VISIBLE
        binding.tvPonselCount.text = "${selectedPhones.size}/4 ponsel"
        binding.btnStartComparison.isEnabled = selectedPhones.size >= 2
        binding.llComparisonContent.visibility = if (selectedPhones.size >= 2) View.VISIBLE else View.GONE
        binding.llEmptyState.visibility = if (selectedPhones.size < 2) View.VISIBLE else View.GONE

        binding.llPhoneContainer.removeAllViews()

        selectedPhones.forEach { phone ->
            val phoneCard = LayoutInflater.from(context).inflate(R.layout.item_phone_card, binding.llPhoneContainer, false)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            phoneCard.layoutParams = params

            val ivPhone = phoneCard.findViewById<ImageView>(R.id.ivPhone)
            val tvPhoneName = phoneCard.findViewById<TextView>(R.id.tvPhoneName)
            val btnRemove = phoneCard.findViewById<ImageView>(R.id.btnRemove)

            Glide.with(this).load(phone.imageUrl).placeholder(R.drawable.placeholder_image).into(ivPhone)
            tvPhoneName.text = "${phone.brand} ${phone.model}"
            btnRemove.setOnClickListener {
                selectedPhoneIds.remove(phone.id)
                selectedPhones.remove(phone)
                updateUI()
            }
            phoneCard.setOnClickListener {
                try {
                    val action = BandingFragmentDirections.actionBandingToDetailProduk(phone.id)
                    findNavController().navigate(action)
                } catch (e: Exception) {
                    Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
                }
            }
            binding.llPhoneContainer.addView(phoneCard)
        }

        if (selectedPhones.size < 4) {
            val parent = binding.cardAddPhone.parent as? ViewGroup
            parent?.removeView(binding.cardAddPhone)
            binding.llPhoneContainer.addView(binding.cardAddPhone)
        }

        updateComparisonContent()
    }

    private fun updateComparisonContent() {
        binding.llComparisonContent.removeAllViews()
        if (selectedPhones.size < 2) return
        val checkedChipId = binding.chipGroupCategories.checkedChipId
        val category = when (checkedChipId) {
            R.id.chipPerforma -> "Performa"
            R.id.chipKamera -> "Kamera"
            R.id.chipLayar -> "Layar"
            R.id.chipBaterai -> "Baterai"
            else -> "Ringkasan"
        }
        when (category) {
            "Ringkasan" -> {
                addComparisonRow("Merek", selectedPhones.map { it.brand })
                addComparisonRow("Model", selectedPhones.map { it.model })
                addComparisonRow("Harga", selectedPhones.map { NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(it.price) })
                addComparisonRow("RAM", selectedPhones.map { "${it.ram}GB" })
                addComparisonRow("Storage", selectedPhones.map { "${it.storage}GB" })
            }
            "Performa" -> {
                addComparisonRow("Chipset", selectedPhones.map { it.chipset })
                addComparisonRow("RAM", selectedPhones.map { "${it.ram}GB" })
            }
            "Kamera" -> {
                addComparisonRow("Kamera", selectedPhones.map { it.camera })
            }
            "Layar" -> {
                addComparisonRow("Layar", selectedPhones.map { "${it.screenSize}\"" })
            }
            "Baterai" -> {
                addComparisonRow("Baterai", selectedPhones.map { "${it.battery}mAh" })
            }
        }
    }

    private fun addComparisonRow(label: String, values: List<String>) {
        val row = LinearLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 16 }
            orientation = LinearLayout.HORIZONTAL
        }
        val tvLabel = TextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = label
            textSize = 14f
            setTextColor(context.getColor(R.color.black))
            setPadding(8, 8, 8, 8)
        }
        row.addView(tvLabel)
        values.forEach { value ->
            val tvValue = TextView(context).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = value
                textSize = 14f
                setTextColor(context.getColor(R.color.black))
                setPadding(8, 8, 8, 8)
                gravity = android.view.Gravity.CENTER
            }
            row.addView(tvValue)
        }
        binding.llComparisonContent.addView(row)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}