package com.example.specrave.model

import android.os.Parcelable
import com.google.firebase.database.PropertyName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Phone(
    @PropertyName("id") val id: String = "",
    @PropertyName("brand") val brand: String = "",
    @PropertyName("model") val model: String = "",
    @PropertyName("price") val price: Long = 0,
    @PropertyName("screen_size") val screenSize: Double = 0.0,
    @PropertyName("storage") val storage: Int = 0,
    @PropertyName("ram") val ram: Int = 0,
    @PropertyName("battery") val battery: Int = 0,
    @PropertyName("camera") val camera: String = "", // Changed to String to match database
    @PropertyName("chipset") val chipset: String = "",
    @PropertyName("is_5g") val is5g: Boolean = false,
    @PropertyName("os") val os: String = "",
    @PropertyName("release_year") val releaseYear: Int = 0,
    @PropertyName("categories") val categories: List<String> = emptyList(), // Changed to List<String>
    @PropertyName("image_url") val imageUrl: String = "",
    @PropertyName("search_count") val searchCount: Long = 0
) : Parcelable