package com.example.specrave.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Phone(
    val id: String = "",
    val brand: String = "",
    val model: String = "",
    val price: Long = 0,
    val screenSize: Double = 0.0,
    val storage: Int = 0,
    val ram: Int = 0,
    val battery: Int = 0,
    val camera: String = "",
    val chipset: String = "",
    val is5g: Boolean = false,
    val os: String = "",
    val releaseYear: Int = 0,
    val categories: List<String> = emptyList(),
    val imageUrl: String = "",
    val searchCount: Long = 0
) : Parcelable