package com.example.specrave.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.specrave.R
import com.example.specrave.adapter.ProductAdapter
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentHomeBinding
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup search bar
        binding.searchBar.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_home_to_navigation_Jelajahi)
        }

        // Setup category buttons
        binding.btnCategoryKamera.setOnClickListener {
            navigateToJelajahiWithCategory("kamera")
        }
        binding.btnCategoryBaterai.setOnClickListener {
            navigateToJelajahiWithCategory("baterai")
        }
        binding.btnCategoryGaming.setOnClickListener {
            navigateToJelajahiWithCategory("gaming")
        }
        binding.btnCategoryLayar.setOnClickListener {
            navigateToJelajahiWithCategory("layar")
        }

        // Setup popular products
        setupPopularProducts()
    }

    private fun navigateToJelajahiWithCategory(category: String) {
        val action = HomeFragmentDirections.actionNavigationHomeToNavigationJelajahi(category)
        findNavController().navigate(action)
    }

    private fun setupPopularProducts() {
        val adapter = ProductAdapter(mutableListOf()) { phone ->
            val action = HomeFragmentDirections.actionNavigationHomeToNavigationDetailProduk(phone.id)
            findNavController().navigate(action)
        }
        binding.rvPopularSearch.adapter = adapter
        binding.rvPopularSearch.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)

        lifecycleScope.launch {
            when (val result = FirebaseService.getPopularPhones()) {
                is Result.Success -> {
                    if (result.data.isEmpty()) {
                        Snackbar.make(binding.root, "Gagal memuat produk favorit", Snackbar.LENGTH_LONG).show()
                    } else {
                        adapter.updatePhones(result.data)
                    }
                }
                is Result.Failure -> {
                    Snackbar.make(binding.root, "Gagal memuat produk favorit", Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) { setupPopularProducts() }
                        .show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}