package com.example.specrave.ui.banding

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.specrave.R
import com.example.specrave.adapter.ProductAdapter
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentSelectPhoneBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class SelectPhoneFragment : Fragment() {

    private var _binding: FragmentSelectPhoneBinding? = null
    private val binding get() = _binding!!
    private lateinit var productAdapter: ProductAdapter
    private val auth = FirebaseAuth.getInstance()
    private val selectedPhoneIds = mutableListOf<String>()
    private val TAG = "PILIH_PONSEL" // Tag untuk logging

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSelectPhoneBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        selectedPhoneIds.addAll(arguments?.getStringArrayList("selectedPhoneIds") ?: emptyList())

        productAdapter = ProductAdapter(mutableListOf()) { phone ->
            if (!selectedPhoneIds.contains(phone.id)) {
                selectedPhoneIds.add(phone.id)

                // --- LOGGING TAMBAHAN ---
                // Log ini untuk memastikan data sedang dikirim
                Log.d(TAG, "Mengirim ID ponsel ke BandingFragment: $selectedPhoneIds")

                val bundle = Bundle().apply { putStringArrayList("selectedPhoneIds", ArrayList(selectedPhoneIds)) }
                findNavController().navigate(R.id.action_selectPhone_to_banding, bundle)
            } else {
                Snackbar.make(binding.root, "Ponsel sudah dipilih", Snackbar.LENGTH_SHORT).show()
            }
        }
        binding.rvPhones.layoutManager = LinearLayoutManager(context)
        binding.rvPhones.adapter = productAdapter

        loadPhones()
    }

    private fun loadPhones() {
        binding.progressBar.visibility = View.VISIBLE
        binding.contentLayout.visibility = View.GONE
        binding.errorLayout.visibility = View.GONE

        lifecycleScope.launch {
            val user = auth.currentUser
            val result = if (user != null) {
                FirebaseService.getSavedPhones(user.uid)
            } else {
                FirebaseService.searchPhones("")
            }
            when (result) {
                is Result.Success -> {
                    binding.progressBar.visibility = View.GONE
                    if (result.data.isEmpty()) {
                        binding.errorLayout.visibility = View.VISIBLE
                        binding.tvErrorMessage.text = getString(R.string.error_empty_products)
                        binding.contentLayout.visibility = View.GONE
                    } else {
                        productAdapter.updatePhones(result.data)
                        binding.contentLayout.visibility = View.VISIBLE
                        binding.errorLayout.visibility = View.GONE
                    }
                }
                is Result.Failure -> {
                    binding.progressBar.visibility = View.GONE
                    binding.errorLayout.visibility = View.VISIBLE
                    binding.tvErrorMessage.text = getString(R.string.error_load_products)
                    Snackbar.make(binding.root, R.string.error_load_products, Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) { loadPhones() }
                        .show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}