package com.example.specrave.ui.jelajahi

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.specrave.R
import com.example.specrave.adapter.ActiveFilterAdapter
import com.example.specrave.adapter.Category
import com.example.specrave.adapter.CategoryAdapter
import com.example.specrave.adapter.Filter
import com.example.specrave.adapter.ProductAdapter
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentJelajahiBinding
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class JelajahiFragment : Fragment() {

    private var _binding: FragmentJelajahiBinding? = null
    private val binding get() = _binding!!
    private lateinit var productAdapter: ProductAdapter
    private lateinit var activeFilterAdapter: ActiveFilterAdapter
    private lateinit var categoryAdapter: CategoryAdapter
    private val activeFilters = mutableListOf<Filter>()
    private val TAG = "JelajahiFragment"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentJelajahiBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup RecyclerViews
        productAdapter = ProductAdapter(mutableListOf()) { phone ->
            try {
                val action = JelajahiFragmentDirections.actionJelajahiToDetailProduk(phone.id)
                findNavController().navigate(action)
            } catch (e: Exception) {
                Log.e(TAG, "Navigation error to DetailProduk", e)
                Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
            }
        }
        binding.rvPopularSearches.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        binding.rvPopularSearches.adapter = productAdapter

        activeFilterAdapter = ActiveFilterAdapter(activeFilters) { filter ->
            activeFilters.remove(filter)
            updateActiveFilters()
        }
        binding.rvActiveFilters.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        binding.rvActiveFilters.adapter = activeFilterAdapter

        val categories = listOf(
            Category("Kamera", R.drawable.ic_camera),
            Category("Baterai", R.drawable.ic_batre),
            Category("Gaming", R.drawable.ic_game),
            Category("Layar", R.drawable.ic_hp)
        )
        categoryAdapter = CategoryAdapter(categories) { category ->
            try {
                val action = JelajahiFragmentDirections.actionJelajahiToHasilSearch(
                    category = category.name.lowercase(),
                    filters = null
                )
                findNavController().navigate(action)
            } catch (e: Exception) {
                Log.e(TAG, "Navigation error to HasilSearch with category ${category.name}", e)
                Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
            }
        }
        binding.rvCategories.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        binding.rvCategories.adapter = categoryAdapter

        // Setup Search
        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val query = binding.etSearch.text.toString().trim()
                if (query.isNotEmpty()) {
                    searchPhones(query)
                }
                true
            } else false
        }
        binding.ivClearSearch.setOnClickListener {
            binding.etSearch.text.clear()
            binding.ivClearSearch.visibility = View.GONE
            clearSearchResults()
        }
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.ivClearSearch.visibility = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Setup Filter
        binding.btnFilter.setOnClickListener {
            try {
                val filterDialog = FilterDialogFragment.newInstance { filters ->
                    activeFilters.clear()
                    activeFilters.addAll(filters)
                    updateActiveFilters()
                    binding.overlayFilter.visibility = View.GONE // Tutup overlay saat dialog ditutup
                }
                filterDialog.show(parentFragmentManager, "FilterDialog")
                binding.overlayFilter.visibility = View.VISIBLE
            } catch (e: Exception) {
                Log.e(TAG, "Error showing FilterDialog", e)
                Snackbar.make(binding.root, R.string.error_open_filter, Snackbar.LENGTH_SHORT).show()
            }
        }

        // Setup Apply Button
        binding.btnApplyFilter.setOnClickListener {
            if (activeFilters.isNotEmpty()) {
                try {
                    val filtersString = activeFilters.joinToString(",") { "${it.name}:${it.value}" }
                    val action = JelajahiFragmentDirections.actionJelajahiToHasilSearch(
                        filters = filtersString,
                        category = null
                    )
                    findNavController().navigate(action)
                } catch (e: Exception) {
                    Log.e(TAG, "Navigation error to HasilSearch with filters", e)
                    Snackbar.make(binding.root, R.string.error_navigation, Snackbar.LENGTH_SHORT).show()
                }
            }
        }

        // Load popular phones
        fetchPopularPhones()

        // Handle back press
        val callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                findNavController().popBackStack()
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, callback)
    }

    private fun fetchPopularPhones() {
        binding.layoutLoading.visibility = View.VISIBLE
        binding.rvPopularSearches.visibility = View.GONE
        binding.layoutEmptySearch.visibility = View.GONE

        lifecycleScope.launch {
            when (val result = FirebaseService.getPopularPhones()) {
                is Result.Success -> {
                    binding.layoutLoading.visibility = View.GONE
                    if (result.data.isEmpty()) {
                        binding.layoutEmptySearch.visibility = View.VISIBLE
                        binding.tvEmptySearchMessage.text = getString(R.string.error_empty_products)
                        Snackbar.make(binding.root, R.string.error_empty_products, Snackbar.LENGTH_LONG)
                            .setAction(R.string.retry) { fetchPopularPhones() }
                            .show()
                    } else {
                        productAdapter.updatePhones(result.data)
                        binding.rvPopularSearches.visibility = View.VISIBLE
                        binding.layoutEmptySearch.visibility = View.GONE
                    }
                }
                is Result.Failure -> {
                    binding.layoutLoading.visibility = View.GONE
                    binding.rvPopularSearches.visibility = View.GONE
                    binding.layoutEmptySearch.visibility = View.VISIBLE
                    binding.tvEmptySearchMessage.text = getString(R.string.error_load_products)
                    Snackbar.make(binding.root, R.string.error_load_products, Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) { fetchPopularPhones() }
                        .show()
                    Log.e(TAG, "Failed to load popular phones", result.exception)
                }
            }
        }
    }

    private fun searchPhones(keyword: String) {
        binding.layoutLoading.visibility = View.VISIBLE
        binding.rvSearchResults.visibility = View.GONE
        binding.layoutEmptySearch.visibility = View.GONE

        lifecycleScope.launch {
            when (val result = FirebaseService.searchPhones(keyword)) {
                is Result.Success -> {
                    binding.layoutLoading.visibility = View.GONE
                    if (result.data.isEmpty()) {
                        binding.tvSearchResultTitle.visibility = View.VISIBLE
                        binding.rvSearchResults.visibility = View.GONE
                        binding.layoutEmptySearch.visibility = View.VISIBLE
                        binding.tvEmptySearchMessage.text = getString(R.string.error_empty_products)
                        Snackbar.make(binding.root, R.string.error_empty_products, Snackbar.LENGTH_LONG)
                            .setAction(R.string.retry) { searchPhones(keyword) }
                            .show()
                    } else {
                        productAdapter.updatePhones(result.data)
                        binding.tvSearchResultTitle.visibility = View.VISIBLE
                        binding.rvSearchResults.visibility = View.VISIBLE
                        binding.layoutEmptySearch.visibility = View.GONE
                        binding.rvSearchResults.layoutManager = LinearLayoutManager(context)
                        binding.rvSearchResults.adapter = productAdapter
                    }
                }
                is Result.Failure -> {
                    binding.layoutLoading.visibility = View.GONE
                    binding.rvSearchResults.visibility = View.GONE
                    binding.layoutEmptySearch.visibility = View.VISIBLE
                    binding.tvEmptySearchMessage.text = getString(R.string.error_load_products)
                    Snackbar.make(binding.root, R.string.error_load_products, Snackbar.LENGTH_LONG)
                        .setAction(R.string.retry) { searchPhones(keyword) }
                        .show()
                    Log.e(TAG, "Failed to search phones with keyword: $keyword", result.exception)
                }
            }
        }
    }

    private fun updateActiveFilters() {
        activeFilterAdapter.updateFilters(activeFilters)
        binding.rvActiveFilters.visibility = if (activeFilters.isEmpty()) View.GONE else View.VISIBLE
        binding.tvFilterCount.text = activeFilters.size.toString()
        binding.tvFilterCount.visibility = if (activeFilters.isEmpty()) View.GONE else View.VISIBLE
        binding.btnApplyFilter.visibility = if (activeFilters.isEmpty()) View.GONE else View.VISIBLE
        binding.overlayFilter.visibility = View.GONE
    }

    private fun clearSearchResults() {
        binding.tvSearchResultTitle.visibility = View.GONE
        binding.rvSearchResults.visibility = View.GONE
        binding.layoutEmptySearch.visibility = View.GONE
        fetchPopularPhones()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}