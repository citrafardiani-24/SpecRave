package com.example.specrave.ui.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.specrave.R
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.FragmentRegisterBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RegisterFragment : Fragment() {

    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!
    private val auth = FirebaseAuth.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnRegister.setOnClickListener {
            val email = binding.etRegisterEmail.text.toString().trim()
            val password = binding.etRegisterPassword.text.toString().trim()
            val name = binding.etRegisterName.text.toString().trim()

            if (email.isEmpty() || password.isEmpty() || name.isEmpty()) {
                Snackbar.make(binding.root, "Semua kolom harus diisi", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            binding.progressBar.visibility = View.VISIBLE
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val user = auth.currentUser
                        val profileData = mapOf(
                            "name" to name,
                            "email" to email,
                            "bio" to "",
                            "joinDate" to SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                            "photoUrl" to ""
                        )
                        lifecycleScope.launch {
                            when (val result = FirebaseService.updateUserProfile(user!!.uid, profileData)) {
                                is Result.Success -> {
                                    binding.progressBar.visibility = View.GONE
                                    Snackbar.make(binding.root, "Registrasi berhasil", Snackbar.LENGTH_SHORT).show()
                                    findNavController().navigate(R.id.action_register_to_profile)
                                }
                                is Result.Failure -> {
                                    binding.progressBar.visibility = View.GONE
                                    Snackbar.make(binding.root, "Gagal menyimpan profil", Snackbar.LENGTH_LONG).show()
                                }
                            }
                        }
                    } else {
                        binding.progressBar.visibility = View.GONE
                        val errorMessage = when (task.exception) {
                            is FirebaseAuthWeakPasswordException -> "Password terlalu lemah"
                            is FirebaseAuthUserCollisionException -> "Email sudah terdaftar"
                            else -> "Registrasi gagal: ${task.exception?.message}"
                        }
                        Snackbar.make(binding.root, errorMessage, Snackbar.LENGTH_LONG).show()
                    }
                }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}