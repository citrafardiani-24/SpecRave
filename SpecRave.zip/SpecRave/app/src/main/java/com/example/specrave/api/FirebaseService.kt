package com.example.specrave.api

import android.util.Log
import com.example.specrave.model.Phone
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await

object FirebaseService {

    private val database = FirebaseDatabase.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private const val TAG = "FirebaseService"

    // Fungsi untuk mapping manual
    private fun mapSnapshotToPhone(snapshot: DataSnapshot): Phone? {
        return try {
            Phone(
                id = snapshot.child("id").getValue(String::class.java) ?: "",
                brand = snapshot.child("brand").getValue(String::class.java) ?: "",
                model = snapshot.child("model").getValue(String::class.java) ?: "",
                price = snapshot.child("price").getValue(Long::class.java) ?: 0L,
                screenSize = snapshot.child("screen_size").getValue(Double::class.java) ?: 0.0,
                storage = snapshot.child("storage").getValue(Int::class.java) ?: 0,
                ram = snapshot.child("ram").getValue(Int::class.java) ?: 0,
                battery = snapshot.child("battery").getValue(Int::class.java) ?: 0,
                camera = snapshot.child("camera").getValue(String::class.java) ?: "",
                chipset = snapshot.child("chipset").getValue(String::class.java) ?: "",
                is5g = snapshot.child("is_5g").getValue(Boolean::class.java) ?: false,
                os = snapshot.child("os").getValue(String::class.java) ?: "",
                releaseYear = snapshot.child("release_year").getValue(Int::class.java) ?: 0,
                categories = snapshot.child("categories").children.mapNotNull { it.getValue(String::class.java) },
                imageUrl = snapshot.child("image_url").getValue(String::class.java) ?: "",
                searchCount = snapshot.child("search_count").getValue(Long::class.java) ?: 0L
            )
        } catch (e: Exception) {
            Log.e(TAG, "mapSnapshotToPhone: Failed to map snapshot for key=${snapshot.key}", e)
            null
        }
    }

    suspend fun getAllPhones(): Result<List<Phone>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            val phones = snapshot.children.mapNotNull { mapSnapshotToPhone(it) }
            Log.d(TAG, "getAllPhones: Loaded ${phones.size} phones: ${phones.map { "${it.brand} ${it.model}" }}")
            Result.Success(phones)
        } catch (e: Exception) {
            Log.e(TAG, "getAllPhones: Failed to fetch phones", e)
            Result.Failure(e)
        }
    }

    suspend fun getSavedPhones(uid: String): Result<List<Phone>> {
        return try {
            val savedSnapshot = database.getReference("saved_phones/$uid").get().await()
            val phoneIds = savedSnapshot.children.mapNotNull { it.key }
            Log.d(TAG, "getSavedPhones: UID=$uid, found ${phoneIds.size} phone IDs: $phoneIds")

            val phones = mutableListOf<Phone>()
            for (phoneId in phoneIds) {
                val phoneSnapshot = database.getReference("phones/$phoneId").get().await()
                mapSnapshotToPhone(phoneSnapshot)?.let {
                    phones.add(it)
                } ?: Log.w(TAG, "getSavedPhones: Phone with ID $phoneId not found in phones node")
            }
            Log.d(TAG, "getSavedPhones: UID=$uid, loaded ${phones.size} phones: ${phones.map { "${it.brand} ${it.model}" }}")
            Result.Success(phones)
        } catch (e: Exception) {
            Log.e(TAG, "getSavedPhones: Failed to fetch saved phones for uid=$uid", e)
            Result.Failure(e)
        }
    }

    suspend fun getAvailableBrands(): Result<List<String>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            val brands = snapshot.children.mapNotNull { mapSnapshotToPhone(it)?.brand }
                .distinct()
                .sorted()
            Log.d(TAG, "getAvailableBrands: Retrieved ${brands.size} brands: $brands")
            Result.Success(brands)
        } catch (e: Exception) {
            Log.e(TAG, "getAvailableBrands: Failed to retrieve brands", e)
            Result.Failure(e)
        }
    }

    suspend fun searchPhones(query: String): Result<List<Phone>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            val phones = snapshot.children.mapNotNull { mapSnapshotToPhone(it) }
            val filteredPhones = if (query.isEmpty()) {
                phones
            } else {
                phones.filter { it.brand.lowercase().contains(query.lowercase()) || it.model.lowercase().contains(query.lowercase()) }
            }
            Log.d(TAG, "searchPhones: Query=$query, found ${filteredPhones.size} phones: ${filteredPhones.map { "${it.brand} ${it.model}" }}")
            Result.Success(filteredPhones)
        } catch (e: Exception) {
            Log.e(TAG, "searchPhones: Failed to search phones with query=$query", e)
            Result.Failure(e)
        }
    }

    suspend fun getPhoneById(phoneId: String): Result<Phone> {
        return try {
            val snapshot = database.getReference("phones/$phoneId").get().await()
            val phone = mapSnapshotToPhone(snapshot)
            if (phone != null) {
                Log.d(TAG, "getPhoneById: Phone found for id=$phoneId")
                Result.Success(phone)
            } else {
                Log.e(TAG, "getPhoneById: Phone not found or failed to parse for id=$phoneId")
                Result.Failure(Exception("Phone not found or failed to parse"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "getPhoneById: Failed to fetch phone for id=$phoneId", e)
            Result.Failure(e)
        }
    }

    suspend fun getUserProfile(uid: String): Result<Map<String, Any>?> {
        return try {
            val snapshot = database.getReference("users/$uid").get().await()
            @Suppress("UNCHECKED_CAST")
            val profile = snapshot.value as? Map<String, Any>
            Log.d(TAG, "getUserProfile: Profile fetched for uid=$uid, profile=$profile")
            Result.Success(profile)
        } catch (e: Exception) {
            Log.e(TAG, "getUserProfile: Failed to fetch profile for uid=$uid", e)
            Result.Failure(e)
        }
    }

    suspend fun updateUserProfile(uid: String, profileData: Map<String, Any>): Result<Unit> {
        return try {
            database.getReference("users/$uid").updateChildren(profileData).await()
            Log.d(TAG, "updateUserProfile: Profile updated for uid=$uid")
            Result.Success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "updateUserProfile: Failed to update profile for uid=$uid", e)
            Result.Failure(e)
        }
    }

    suspend fun getPopularPhones(): Result<List<Phone>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            val phones = snapshot.children.mapNotNull { mapSnapshotToPhone(it) }
                .sortedByDescending { it.searchCount }
                .take(5)
            Log.d(TAG, "getPopularPhones: Retrieved ${phones.size} popular phones")
            Result.Success(phones)
        } catch (e: Exception) {
            Log.e(TAG, "getPopularPhones: Failed to fetch popular phones", e)
            Result.Failure(e)
        }
    }

    suspend fun getCategoryPhones(category: String): Result<List<Phone>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            val phones = snapshot.children.mapNotNull { mapSnapshotToPhone(it) }
                .filter { phone -> phone.categories.any { it.equals(category, ignoreCase = true) } }
            Log.d(TAG, "getCategoryPhones: Category=$category, found ${phones.size} phones")
            Result.Success(phones)
        } catch (e: Exception) {
            Log.e(TAG, "getCategoryPhones: Failed to fetch phones for category=$category", e)
            Result.Failure(e)
        }
    }

    suspend fun filterPhones(
        priceRange: String?,
        brands: List<String>,
        screenSizes: List<String>,
        storages: List<String>,
        is5g: Boolean?
    ): Result<List<Phone>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            var phones = snapshot.children.mapNotNull { mapSnapshotToPhone(it) }
            Log.d(TAG, "filterPhones: Initial phones retrieved: ${phones.size}")
            Log.d(TAG, "filterPhones: Phone details: ${phones.map { "${it.brand} ${it.model}, price=${it.price}, screenSize=${it.screenSize}, storage=${it.storage}, is5g=${it.is5g}" }}")

            // Filter by price range
            priceRange?.let { range ->
                phones = when {
                    range == "Di bawah Rp2.000.000" -> phones.filter { it.price <= 2_000_000 }
                    range == "Rp2.000.000 - Rp4.000.000" -> phones.filter { it.price in 2_000_000..4_000_000 }
                    range == "Rp4.000.000 - Rp6.000.000" -> phones.filter { it.price in 4_000_000..6_000_000 }
                    range == "Rp6.000.000 - Rp8.000.000" -> phones.filter { it.price in 6_000_000..8_000_000 }
                    range == "Rp8.000.000 - Rp12.000.000" -> phones.filter { it.price in 8_000_000..12_000_000 }
                    range == "Di atas Rp12.000.000" -> phones.filter { it.price > 12_000_000 }
                    else -> phones
                }
                Log.d(TAG, "filterPhones: After priceRange=$range, phones left: ${phones.size}")
            }

            // Filter by brands
            if (brands.isNotEmpty()) {
                phones = phones.filter { phone ->
                    brands.any { brand -> phone.brand.equals(brand, ignoreCase = true) }
                }
                Log.d(TAG, "filterPhones: After brands=$brands, phones left: ${phones.size}")
            }

            // Filter by screen sizes
            if (screenSizes.isNotEmpty()) {
                phones = phones.filter { phone ->
                    screenSizes.any { screenSize ->
                        when (screenSize) {
                            "Di bawah 6 inch" -> phone.screenSize < 6.0
                            "6 - 6.5 inch" -> phone.screenSize in 6.0..6.5
                            "6.5 - 7 inch" -> phone.screenSize in 6.51..7.0
                            "Di atas 7 inch" -> phone.screenSize > 7.0
                            else -> false
                        }
                    }
                }
                Log.d(TAG, "filterPhones: After screenSizes=$screenSizes, phones left: ${phones.size}")
            }

            // Filter by storages
            if (storages.isNotEmpty()) {
                phones = phones.filter { phone ->
                    storages.any { storage ->
                        val storageValue = storage.removeSuffix("GB").replace("TB", "000").toIntOrNull()
                        storageValue != null && storageValue == phone.storage
                    }
                }
                Log.d(TAG, "filterPhones: After storages=$storages, phones left: ${phones.size}")
            }

            // Filter by 5G
            is5g?.let {
                phones = phones.filter { phone -> phone.is5g == it }
                Log.d(TAG, "filterPhones: After is5g=$is5g, phones left: ${phones.size}")
            }

            Log.d(TAG, "filterPhones: Final filtered phones: ${phones.size}")
            Result.Success(phones)
        } catch (e: Exception) {
            Log.e(TAG, "filterPhones: Failed to apply filters", e)
            Result.Failure(e)
        }
    }

    suspend fun isPhoneSaved(uid: String, phoneId: String): Result<Boolean> {
        return try {
            val snapshot = database.getReference("saved_phones/$uid/$phoneId").get().await()
            Log.d(TAG, "isPhoneSaved: Phone $phoneId isSaved=${snapshot.exists()} for uid=$uid")
            Result.Success(snapshot.exists())
        } catch (e: Exception) {
            Log.e(TAG, "isPhoneSaved: Failed to check if phone $phoneId is saved for uid=$uid", e)
            Result.Failure(e)
        }
    }

    suspend fun savePhone(uid: String, phoneId: String): Result<Unit> {
        return try {
            database.getReference("saved_phones/$uid/$phoneId").setValue(true).await()
            Log.d(TAG, "savePhone: Phone $phoneId saved for uid=$uid")
            Result.Success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "savePhone: Failed to save phone $phoneId for uid=$uid", e)
            Result.Failure(e)
        }
    }

    suspend fun unsavePhone(uid: String, phoneId: String): Result<Unit> {
        return try {
            database.getReference("saved_phones/$uid/$phoneId").removeValue().await()
            Log.d(TAG, "unsavePhone: Phone $phoneId unsaved for uid=$uid")
            Result.Success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "unsavePhone: Failed to unsave phone $phoneId for uid=$uid", e)
            Result.Failure(e)
        }
    }
}

sealed class Result<out T> {
    data class Success<out T>(val data: T) : Result<T>()
    data class Failure(val exception: Exception) : Result<Nothing>()
}