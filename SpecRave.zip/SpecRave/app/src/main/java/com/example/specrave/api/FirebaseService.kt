package com.example.specrave.api

import com.example.specrave.model.Phone
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await

object FirebaseService {

    private val database = FirebaseDatabase.getInstance()
    private val auth = FirebaseAuth.getInstance()

    // --- FUNGSI BARU UNTUK MAPPING MANUAL ---
    // Fungsi ini mengubah DataSnapshot menjadi objek Phone secara eksplisit untuk menghindari error.
    private fun mapSnapshotToPhone(snapshot: DataSnapshot): Phone? {
        return try {
            Phone(
                id = snapshot.child("id").getValue(String::class.java) ?: "",
                brand = snapshot.child("brand").getValue(String::class.java) ?: "",
                model = snapshot.child("model").getValue(String::class.java) ?: "",
                price = snapshot.child("price").getValue(Long::class.java) ?: 0L,
                screenSize = snapshot.child("screen_size").getValue(Double::class.java) ?: 0.0,
                storage = snapshot.child("storage").getValue(Int::class.java) ?: 0,
                ram = snapshot.child("ram").getValue(Int::class.java) ?: 0,
                battery = snapshot.child("battery").getValue(Int::class.java) ?: 0,
                camera = snapshot.child("camera").getValue(String::class.java) ?: "",
                chipset = snapshot.child("chipset").getValue(String::class.java) ?: "",
                is5g = snapshot.child("is_5g").getValue(Boolean::class.java) ?: false,
                os = snapshot.child("os").getValue(String::class.java) ?: "",
                releaseYear = snapshot.child("release_year").getValue(Int::class.java) ?: 0,
                categories = snapshot.child("categories").children.mapNotNull { it.getValue(String::class.java) },
                imageUrl = snapshot.child("image_url").getValue(String::class.java) ?: "",
                searchCount = snapshot.child("search_count").getValue(Long::class.java) ?: 0L
            )
        } catch (e: Exception) {
            null // Jika ada error saat mapping, kembalikan null
        }
    }

    suspend fun searchPhones(query: String): Result<List<Phone>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            val phones = snapshot.children.mapNotNull { mapSnapshotToPhone(it) }
                .filter { it.brand.lowercase().contains(query.lowercase()) || it.model.lowercase().contains(query.lowercase()) }
            Result.Success(phones)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun getSavedPhones(uid: String): Result<List<Phone>> {
        return try {
            val savedSnapshot = database.getReference("saved_phones/$uid").get().await()
            val phoneIds = savedSnapshot.children.mapNotNull { it.key }
            val phones = mutableListOf<Phone>()
            for (phoneId in phoneIds) {
                val phoneSnapshot = database.getReference("phones/$phoneId").get().await()
                mapSnapshotToPhone(phoneSnapshot)?.let { phones.add(it) }
            }
            Result.Success(phones)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun getPhoneById(phoneId: String): Result<Phone> {
        return try {
            val snapshot = database.getReference("phones/$phoneId").get().await()
            val phone = mapSnapshotToPhone(snapshot)
            if (phone != null) Result.Success(phone) else Result.Failure(Exception("Phone not found or failed to parse"))
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun getUserProfile(uid: String): Result<Map<String, Any>?> {
        return try {
            val snapshot = database.getReference("users/$uid").get().await()
            @Suppress("UNCHECKED_CAST")
            Result.Success(snapshot.value as? Map<String, Any>)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun updateUserProfile(uid: String, profileData: Map<String, Any>): Result<Unit> {
        return try {
            database.getReference("users/$uid").updateChildren(profileData).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun getPopularPhones(): Result<List<Phone>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            val phones = snapshot.children.mapNotNull { mapSnapshotToPhone(it) }
                .sortedByDescending { it.searchCount }
                .take(5)
            Result.Success(phones)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun getCategoryPhones(category: String): Result<List<Phone>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            val phones = snapshot.children.mapNotNull { mapSnapshotToPhone(it) }
                .filter { phone -> phone.categories.any { it.equals(category, ignoreCase = true) } }
            Result.Success(phones)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun filterPhones(
        priceRange: String?,
        brands: List<String>,
        screenSizes: List<String>,
        storages: List<String>,
        is5g: Boolean?
    ): Result<List<Phone>> {
        return try {
            val snapshot = database.getReference("phones").get().await()
            var phones = snapshot.children.mapNotNull { mapSnapshotToPhone(it) }

            priceRange?.let {
                phones = phones.filter { phone ->
                    when (it) {
                        "below_2m" -> phone.price < 2_000_000
                        "2m_4m" -> phone.price in 2_000_000..4_000_000
                        "4m_6m" -> phone.price in 4_000_001..6_000_000
                        "6m_8m" -> phone.price in 6_000_001..8_000_000
                        "8m_12m" -> phone.price in 8_000_001..12_000_000
                        "above_12m" -> phone.price > 12_000_000
                        else -> true
                    }
                }
            }

            if (brands.isNotEmpty()) {
                phones = phones.filter { it.brand in brands }
            }

            if (screenSizes.isNotEmpty()) {
                phones = phones.filter { phone ->
                    screenSizes.any { screenSize ->
                        when (screenSize) {
                            "Di bawah 6 inch" -> phone.screenSize < 6.0
                            "6 - 6.5 inch" -> phone.screenSize in 6.0..6.5
                            "6.5 - 7 inch" -> phone.screenSize > 6.5 && phone.screenSize <= 7.0
                            "Di atas 7 inch" -> phone.screenSize > 7.0
                            else -> false
                        }
                    }
                }
            }

            if (storages.isNotEmpty()) {
                phones = phones.filter { phone ->
                    storages.any { storage ->
                        storage.removeSuffix("GB").toIntOrNull()?.let { it == phone.storage } ?: false
                    }
                }
            }

            is5g?.let {
                phones = phones.filter { phone -> phone.is5g == it }
            }

            Result.Success(phones)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun isPhoneSaved(uid: String, phoneId: String): Result<Boolean> {
        return try {
            val snapshot = database.getReference("saved_phones/$uid/$phoneId").get().await()
            Result.Success(snapshot.exists())
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun savePhone(uid: String, phoneId: String): Result<Unit> {
        return try {
            database.getReference("saved_phones/$uid/$phoneId").setValue(true).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }

    suspend fun unsavePhone(uid: String, phoneId: String): Result<Unit> {
        return try {
            database.getReference("saved_phones/$uid/$phoneId").removeValue().await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Failure(e)
        }
    }
}

sealed class Result<out T> {
    data class Success<out T>(val data: T) : Result<T>()
    data class Failure(val exception: Exception) : Result<Nothing>()
}