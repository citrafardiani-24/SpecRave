package com.example.specrave.ui.jelajahi

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Filter(val name: String, val value: String) : Parcelable