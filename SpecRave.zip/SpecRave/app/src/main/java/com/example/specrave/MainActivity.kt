package com.example.specrave

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private val auth = FirebaseAuth.getInstance()
    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        try {
            val navHostFragment = supportFragmentManager
                .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
            navController = navHostFragment.navController
            Log.d(TAG, "NavController initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize NavController", e)
            return
        }

        val navView: BottomNavigationView = binding.navView
        navView.setupWithNavController(navController)

        updateHeaderProfileImage()

        auth.addAuthStateListener {
            Log.d(TAG, "Auth state changed: user=${it.currentUser?.uid}")
            updateHeaderProfileImage()
        }

        binding.layoutHeader.profileImage.setOnClickListener {
            try {
                navController.navigate(R.id.navigation_Profile)
                Log.d(TAG, "Navigating to ProfileFragment")
            } catch (e: Exception) {
                Log.e(TAG, "Navigation error to Profile", e)
            }
        }

        // Listen for profile changes in Firebase
        auth.currentUser?.uid?.let { uid ->
            FirebaseDatabase.getInstance().getReference("users/$uid")
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        Log.d(TAG, "Profile data changed for uid=$uid")
                        updateHeaderProfileImage()
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.e(TAG, "Failed to listen for profile changes", error.toException())
                    }
                })
        }
    }

    private fun updateHeaderProfileImage() {
        val user = auth.currentUser
        Log.d(TAG, "Updating profile image, user=${user?.uid}")
        if (user != null) {
            lifecycleScope.launch {
                when (val result = FirebaseService.getUserProfile(user.uid)) {
                    is Result.Success -> {
                        val photoUrl = result.data?.get("photoUrl")?.toString()
                        Log.d(TAG, "Firebase photoUrl: $photoUrl")
                        if (!photoUrl.isNullOrBlank() && photoUrl != "") {
                            Glide.with(this@MainActivity)
                                .load(photoUrl)
                                .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .skipMemoryCache(true)
                                .placeholder(R.drawable.profil1)
                                .error(R.drawable.profil1)
                                .into(binding.layoutHeader.profileImage)
                        } else {
                            Log.d(TAG, "photoUrl is invalid, loading profil1")
                            Glide.with(this@MainActivity)
                                .load(R.drawable.profil1)
                                .diskCacheStrategy(DiskCacheStrategy.NONE)
                                .skipMemoryCache(true)
                                .placeholder(R.drawable.profil1)
                                .error(R.drawable.profil1)
                                .into(binding.layoutHeader.profileImage)
                        }
                    }
                    is Result.Failure -> {
                        Log.e(TAG, "Failed to load user profile", result.exception)
                        Glide.with(this@MainActivity)
                            .load(R.drawable.profil1)
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true)
                            .placeholder(R.drawable.profil1)
                            .error(R.drawable.profil1)
                            .into(binding.layoutHeader.profileImage)
                    }
                }
            }
        } else {
            Log.d(TAG, "No user logged in, loading default profil1")
            Glide.with(this@MainActivity)
                .load(R.drawable.profil1)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .placeholder(R.drawable.profil1)
                .error(R.drawable.profil1)
                .into(binding.layoutHeader.profileImage)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}