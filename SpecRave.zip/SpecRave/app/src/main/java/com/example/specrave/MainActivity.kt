package com.example.specrave

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.bumptech.glide.Glide
import com.example.specrave.api.FirebaseService
import com.example.specrave.api.Result
import com.example.specrave.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private val auth = FirebaseAuth.getInstance()
    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inisialisasi NavController dengan aman
        try {
            val navHostFragment = supportFragmentManager
                .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
            navController = navHostFragment.navController
            Log.d(TAG, "NavController initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize NavController", e)
            return
        }

        // Setup BottomNavigationView dengan NavController
        val navView: BottomNavigationView = binding.navView
        navView.setupWithNavController(navController)

        // Update gambar profil di header
        updateHeaderProfileImage()

        // Listener untuk perubahan status autentikasi
        auth.addAuthStateListener {
            updateHeaderProfileImage()
        }

        // Klik pada profileImage di header untuk navigasi ke ProfileFragment
        binding.layoutHeader.profileImage.setOnClickListener {
            try {
                navController.navigate(R.id.navigation_Profile)
            } catch (e: Exception) {
                Log.e(TAG, "Navigation error to Profile", e)
            }
        }
    }

    private fun updateHeaderProfileImage() {
        val user = auth.currentUser
        if (user != null) {
            lifecycleScope.launch {
                when (val result = FirebaseService.getUserProfile(user.uid)) {
                    is Result.Success -> {
                        val photoUrl = result.data?.get("photoUrl")?.toString()
                        Glide.with(this@MainActivity)
                            .load(photoUrl ?: R.drawable.profil1)
                            .into(binding.layoutHeader.profileImage)
                    }
                    is Result.Failure -> {
                        Glide.with(this@MainActivity)
                            .load(R.drawable.profil1)
                            .into(binding.layoutHeader.profileImage)
                    }
                }
            }
        } else {
            Glide.with(this@MainActivity)
                .load(R.drawable.profil1)
                .into(binding.layoutHeader.profileImage)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}