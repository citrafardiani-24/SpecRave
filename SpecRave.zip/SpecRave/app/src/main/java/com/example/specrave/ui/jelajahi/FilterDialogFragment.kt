package com.example.specrave.ui.jelajahi

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import com.example.specrave.R

import com.example.specrave.databinding.FragmentFilterDialogBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class FilterDialogFragment : BottomSheetDialogFragment() {

    private var _binding: FragmentFilterDialogBinding? = null
    private val binding get() = _binding!!
    private var onApply: ((List<Filter>) -> Unit)? = null
    private val TAG = "FilterDialogFragment"

    companion object {
        fun newInstance(onApply: (List<Filter>) -> Unit): FilterDialogFragment {
            val fragment = FilterDialogFragment()
            fragment.onApply = onApply
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFilterDialogBinding.inflate(inflater, container, false)
        Log.d(TAG, "onCreateView: Dialog view created")
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d(TAG, "onViewCreated: Setting up dialog")

        val behavior = BottomSheetBehavior.from(binding.dialogFilterContentRoot)
        behavior.isHideable = true
        behavior.peekHeight = (resources.displayMetrics.heightPixels * 0.9).toInt()
        behavior.state = BottomSheetBehavior.STATE_EXPANDED
        behavior.isDraggable = true

        binding.chipAturUlang.setOnClickListener {
            binding.chipGroupPrice.clearCheck()
            binding.chipGroupBrand.clearCheck()
            binding.chipGroupScreenSize.clearCheck()
            binding.chipGroupStorage.clearCheck()
            binding.chipGroup5G.clearCheck()
            Log.d(TAG, "Atur Ulang clicked")
        }

        binding.chipTerapkan.setOnClickListener {
            val filters = mutableListOf<Filter>()
            binding.chipGroupPrice.checkedChipId.let { id ->
                if (id != View.NO_ID) {
                    val chip = binding.chipGroupPrice.findViewById<com.google.android.material.chip.Chip>(id)
                    filters.add(Filter("price_range", chip.text.toString()))
                    Log.d(TAG, "Price filter selected: ${chip.text}")
                }
            }
            binding.chipGroupBrand.checkedChipIds.forEach { id ->
                val chip = binding.chipGroupBrand.findViewById<com.google.android.material.chip.Chip>(id)
                filters.add(Filter("brand", chip.text.toString()))
                Log.d(TAG, "Brand filter selected: ${chip.text}")
            }
            binding.chipGroupScreenSize.checkedChipIds.forEach { id ->
                val chip = binding.chipGroupScreenSize.findViewById<com.google.android.material.chip.Chip>(id)
                filters.add(Filter("screen_size", chip.text.toString()))
                Log.d(TAG, "Screen size filter selected: ${chip.text}")
            }
            binding.chipGroupStorage.checkedChipIds.forEach { id ->
                val chip = binding.chipGroupStorage.findViewById<com.google.android.material.chip.Chip>(id)
                filters.add(Filter("storage", chip.text.toString()))
                Log.d(TAG, "Storage filter selected: ${chip.text}")
            }
            binding.chipGroup5G.checkedChipId.let { id ->
                if (id != View.NO_ID) {
                    val chip = binding.chipGroup5G.findViewById<com.google.android.material.chip.Chip>(id)
                    filters.add(Filter("is_5g", chip.text.toString()))
                    Log.d(TAG, "5G filter selected: ${chip.text}")
                }
            }
            onApply?.invoke(filters)
            Log.d(TAG, "Terapkan clicked with filters: $filters")
            dismiss()
        }

        binding.btnCloseFilter.setOnClickListener {
            Log.d(TAG, "Close button clicked")
            dismiss()
        }

        binding.filterHeader.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }

        // Tutup overlay di parent fragment saat dialog ditutup
        dialog?.setOnDismissListener {
            Log.d(TAG, "Dialog dismissed")
            val parentFragment = parentFragment
            if (parentFragment is JelajahiFragment) {
                parentFragment.requireView().findViewById<View>(R.id.overlayFilter)?.visibility = View.GONE
                Log.d(TAG, "Overlay closed in JelajahiFragment")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d(TAG, "onDestroyView: Cleaning up")
        _binding = null
    }
}