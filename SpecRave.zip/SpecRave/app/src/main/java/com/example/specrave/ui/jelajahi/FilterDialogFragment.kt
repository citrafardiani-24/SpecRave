package com.example.specrave.ui.jelajahi

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import com.example.specrave.R
import com.example.specrave.adapter.Filter
import com.example.specrave.databinding.FragmentFilterDialogBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class FilterDialogFragment : BottomSheetDialogFragment() {

    private var _binding: FragmentFilterDialogBinding? = null
    private val binding get() = _binding!!
    private var onApply: ((List<Filter>) -> Unit)? = null
    private val TAG = "FilterDialogFragment"

    companion object {
        fun newInstance(onApply: (List<Filter>) -> Unit): FilterDialogFragment {
            val fragment = FilterDialogFragment()
            fragment.onApply = onApply
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFilterDialogBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val behavior = BottomSheetBehavior.from(binding.dialogFilterContentRoot)
        behavior.isHideable = true
        behavior.peekHeight = (resources.displayMetrics.heightPixels * 0.9).toInt() // 90% tinggi layar
        behavior.state = BottomSheetBehavior.STATE_EXPANDED // Mulai dalam keadaan terbuka penuh
        behavior.isDraggable = true

        binding.chipAturUlang.setOnClickListener {
            binding.chipGroupPrice.clearCheck()
            binding.chipGroupBrand.clearCheck()
            binding.chipGroupScreenSize.clearCheck()
            binding.chipGroupStorage.clearCheck()
            binding.chipGroup5G.clearCheck()
            Log.d(TAG, "Atur Ulang clicked")
        }

        binding.chipTerapkan.setOnClickListener {
            val filters = mutableListOf<Filter>()
            binding.chipGroupPrice.checkedChipId.let { id ->
                if (id != View.NO_ID) {
                    val chip = binding.chipGroupPrice.findViewById<com.google.android.material.chip.Chip>(id)
                    val priceRange = when (chip.id) {
                        R.id.chipPriceRange1 -> "below_2m"
                        R.id.chipPriceRange2 -> "2m_4m"
                        R.id.chipPriceRange3 -> "4m_6m"
                        R.id.chipPriceRange4 -> "6m_8m"
                        R.id.chipPriceRange5 -> "8m_12m"
                        R.id.chipPriceRange6 -> "above_12m"
                        else -> null
                    }
                    priceRange?.let { filters.add(Filter("price_range", chip.text.toString())) }
                }
            }
            binding.chipGroupBrand.checkedChipIds.forEach { id ->
                val chip = binding.chipGroupBrand.findViewById<com.google.android.material.chip.Chip>(id)
                filters.add(Filter("brand", chip.text.toString()))
            }
            binding.chipGroupScreenSize.checkedChipIds.forEach { id ->
                val chip = binding.chipGroupScreenSize.findViewById<com.google.android.material.chip.Chip>(id)
                val screenSize = when (chip.id) {
                    R.id.chipScreenSize1 -> "below_6"
                    R.id.chipScreenSize2 -> "6_6.5"
                    R.id.chipScreenSize3 -> "6.5_7"
                    R.id.chipScreenSize4 -> "above_7"
                    else -> null
                }
                screenSize?.let { filters.add(Filter("screen_size", chip.text.toString())) }
            }
            binding.chipGroupStorage.checkedChipIds.forEach { id ->
                val chip = binding.chipGroupStorage.findViewById<com.google.android.material.chip.Chip>(id)
                filters.add(Filter("storage", chip.text.toString()))
            }
            binding.chipGroup5G.checkedChipId.let { id ->
                if (id != View.NO_ID) {
                    val chip = binding.chipGroup5G.findViewById<com.google.android.material.chip.Chip>(id)
                    filters.add(Filter("is_5g", chip.text.toString()))
                }
            }
            onApply?.invoke(filters)
            dismiss()
            Log.d(TAG, "Terapkan clicked with filters: $filters")
        }

        binding.btnCloseFilter.setOnClickListener {
            dismiss()
            Log.d(TAG, "Close button clicked")
        }

        binding.filterHeader.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }

        // Tutup overlay di parent fragment saat dialog ditutup
        dialog?.setOnDismissListener {
            val parentFragment = parentFragment as? JelajahiFragment
            parentFragment?.let {
                it.requireView().findViewById<View>(R.id.overlayFilter)?.visibility = View.GONE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}